﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;



public partial class Book : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=D:\\work\\OnlineBookShopping11\\OnlineBookShopping11\\App_Data\\Database.mdf;Integrated Security=True;Connect Timeout=30");


    protected void btnSave_Click(object sender, EventArgs e)
    {
       con.Open();


        
        SqlCommand cmd = con.CreateCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "insert into BookTable values ('" + txtId.Text +"','" + txtTitle.Text + "', '" + txtAuthor.Text + "' ,'" + FileUpload1 + "','" + txtPrice.Text + "','" + txtQuantity.Text + "')";
        
        cmd.ExecuteNonQuery();

        con.Close();
    }
    
}
             