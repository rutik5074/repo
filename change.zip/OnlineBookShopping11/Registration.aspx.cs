﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void Password_TextChanged(object sender, EventArgs e)
    {

    }
    protected void RadioButton1_SelectedIndexChanged(object sender, EventArgs e)
    {
       

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection("Data Source=Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"D:\\asp proje\\OnlineBookShopping11\\OnlineBookShopping11\\App_Data\\Database.mdf\";Integrated Security=True");
        con.Open();
        SqlCommand cmd = new SqlCommand("insert into Table"+ "(UserName,Address,Gender,Password) values (@UserName,@Address,@Gender,@Password)",con);
        cmd.Parameters.AddWithValue("@UserName",UName.Text);
        cmd.Parameters.AddWithValue("@Address", Address.Text);
        cmd.Parameters.AddWithValue("@Gender", DropDownList1.SelectedItem.Value);
        cmd.Parameters.AddWithValue("@Password", Password.Text);
        cmd.ExecuteNonQuery();
        Label1.Text = "Registered Successfully";
    }
}