﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class Login : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"D:\\asp proje\\OnlineBookShopping11\\OnlineBookShopping11\\App_Data\\Database.mdf\";Integrated Security=True");
    int i;
   
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        i = 0;
        con.Open();
        SqlCommand cmd = con.CreateCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "Select * from Logintbl where LUserName='" + txtUsername.Text + "' and LPassword '" + txtPassword.Text + "'";
        cmd.ExecuteNonQuery();
        DataTable dt = new DataTable();
        SqlDataAdapter da= new SqlDataAdapter(cmd);
        da.Fill(dt);
        i =Convert.ToInt32(dt.Rows.Count.ToString());

       if(i == 1)
        {
            Response.Redirect("Home.aspx");
        }
        else
        {
            Label1.Text= "Invalid Username or Password";
        }
        

        con.Close();
       


    }
}